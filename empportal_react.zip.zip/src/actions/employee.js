import axios from 'axios';
import {
    ADD_EMPLOYEE, VIEW_EMPLOYEE,
} from './types';

// Register Employee
export const register = ({ empId, name, age, email, mobile, salary, address, password  }) => async dispatch => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
  
    const body = JSON.stringify({ empId, name, age, email, mobile, salary, address, password  });

    debugger;
  
    const res = await axios.post('http://localhost:5000/api/employee', body, config);

    const empres = await axios.get('http://localhost:5000/api/employee');
  
    dispatch({
      type: VIEW_EMPLOYEE,
      payload: empres.data
    });

    // dispatch({
    //   type: ADD_EMPLOYEE,
    //   payload: res.data
    // });
  };

  // Get posts
export const getAllUsers = () => async dispatch => {

    const res = await axios.get('http://localhost:5000/api/employee');

    debugger;

    console.log(res);

    dispatch({
      type: VIEW_EMPLOYEE,
      payload: res.data
    });


  
}

  
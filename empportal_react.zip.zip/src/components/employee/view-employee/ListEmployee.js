import React, {useEffect} from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {getAllUsers} from '../../../actions/employee';

const ListEmployee = (getAllUsers) => {
    const emp_List = useSelector(state => state.listEmployee);
    useEffect(() => {
        getAllUsers()

    }, [])
    console.log(emp_List);
    return (
        <div className="">

            <table className="table">
                <thead>
                    <tr>
                        <th> Name</th>
                        <th> Email</th>
                        <th> Address</th>
                        <th> Mobile</th>
                        <th> Salary</th>

                        <th> Action </th>
                    </tr>
                </thead>
                <tbody>
                        <tr >
                            <td >Sharath </td>
                            <td >Sharath </td>
                            <td > Sharath</td>
                            <td > Sharath</td>
                            <td > Sharath</td>

                            <td> 
                                <button className="btn btn-primary mr-2">Edit</button>
                                <button className="btn btn-danger">Delete</button>

                            </td>

                           </tr>
                
                    

                </tbody>
            </table>

        </div>
    );
}



ListEmployee.prototype = {
    getAllUsers : PropTypes.func.isRequired,
  }


  
export default connect(null,{getAllUsers})(ListEmployee);


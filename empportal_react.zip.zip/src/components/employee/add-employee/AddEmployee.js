import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import ListEmployee from '../view-employee/ListEmployee';
import {register} from '../../../actions/employee';


const AddEmployee = ({register}) => {

     const [formData, setFormData] = useState({
      empId:'',
    name: '',
    age: '',
    email:'',
    mobile:'',
    salary:'',
    address:'',
    password:'',
  });

  const { empId, name, age, email, mobile, salary, address, password  } = formData;

  const onChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = e => {
          console.log(formData);
          debugger; 
          register({ empId, name, age, email, mobile, salary, address, password})
        console.log(e)
}
    return (
        
        <div className="row container-fluid border p-4 " >
         <div className="col-4">
         <h3>Add Employee</h3>   
         <form onSubmit={e => onSubmit(e)}>
        <div className="border p-4">

        <div className="form-group">
            <input
              type="text"
              value={empId}
              className="form-control"
              placeholder="Employee ID"
              name="empId"
              required
             onChange={e => onChange(e)}
            />
          </div>

          <div className="form-group">
            <input
              type="text"
              value={name}
              className="form-control"
              placeholder="Name"
              name="name"
              required
             onChange={e => onChange(e)}
              minLength="20"
            />
          </div>

          <div className="form-group">
            <input
              type="number"
              value={age}
              className="form-control"
              placeholder="Age"
              name="age"
              onChange={e => onChange(e)}
              required
            />
          </div>

          <div className="form-group">
            <input
              type="email"
              value={email}
              className="form-control"
              placeholder="Email"
              name="email"
              onChange={e => onChange(e)}
              required
            />
          </div>

          <div className="form-group">
            <input
              type="number"
              value={mobile}
              className="form-control"
              placeholder="Mobile"
              name="mobile"
               onChange={e => onChange(e)}
              required
            />
          </div>
  
          <div className="form-group">
            <input
              type="number"
              value={salary}
              name="salary"
              className="form-control"
              placeholder="Salary"
              onChange={e => onChange(e)}
              required
            />
          </div>

          <div className="form-group">
            <input
              type="password"
              value={password}
              name="password"
              className="form-control"
              placeholder="Password"
              onChange={e => onChange(e)}
              required
            />
          </div>


          <div className="form-group">
            <textarea
              rows="2"
              s="50"
              value={address}
              name="address"
              className="form-control"
              placeholder="Address"
              onChange={e => onChange(e)}
              required
            />
          </div>
          {/* <div className="">
              <input type="radio" id="permanent" name="permanent address"  className="form-control" value="isPermanent"  />
              Permanent address

          </div> */}
                    <div className="col mt-2 py-2">
                    <input type="submit" className="form-group btn btn-primary px-4" value="Submit" />
                    </div>

          </div>
          </form>
         </div>   

         <div className="col-8">
         <h3>View Employee</h3>  
         <div className="border">
         <ListEmployee />

             </div> 
         </div>   


        </div>
      );
}


AddEmployee.prototype = {
  register : PropTypes.func.isRequired,
}


export default connect(null,{register})(AddEmployee);


import React, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { login } from '../../actions/auth';
import './Login.css';


const Login = ({ login }) => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const { email, password } = formData;

  const onChange = e => setFormData({...formData, [e.target.name] : e.target.value});


  const onSubmit = async e => {
    e.preventDefault();
    login(email, password);
  };

 

  return (
    <Fragment>
    <div className="bordertop"></div>

      <div className="container w-25 border p-3 mt-4">
      <h2 className>Employee Portal</h2>     
       <p className="lead">
        <i className="fas fa-user" /> Sign Into Your Account
      </p>
      <form className="form" onSubmit={e => onSubmit(e)}>
      <div class="form-group">
    <label for="email">Email address:</label>
    <input
            type="email"
            class="form-control"
            placeholder="Email Address"
            name="email"
            value={email}
            onChange={e => onChange(e)}
            required
          />
  </div>
     
        <div className="form-group">
        <label for="pwd">Password:</label>
          <input
            type="password"
            class="form-control"
            placeholder="Password"
            name="password"
            value={password}
            onChange={e => onChange(e)}
            minLength="6"
          />
        </div>
        <input type="submit" className="btn btn-warning" value="Login" />
      </form>
      </div>


      <Link to = '/add-employee'>ADD EMPLOYEE</Link>
      </Fragment>

  );
};

Login.propTypes = {
  login: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool
};

const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated
});

export default connect(mapStateToProps, { login })(Login);

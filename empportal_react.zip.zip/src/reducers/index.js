import { combineReducers } from 'redux';
import auth from './auth';
import employee from './employee';
import listEmployee from './listEmployee';

export default combineReducers({
  auth,  
  employee,
  listEmployee
});

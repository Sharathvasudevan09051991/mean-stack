import {
    VIEW_EMPLOYEE,
  } from '../actions/types';

  const initialState = {
    employees: [],
  };

  export default function(state = initialState, action) {
    const { type, payload } = action;
  
    switch (type) {

      case VIEW_EMPLOYEE:
        return  payload
        
      default:
        return state;
    }
  }
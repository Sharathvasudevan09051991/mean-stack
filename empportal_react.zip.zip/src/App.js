import React, { Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import './App.css';
import Login from './components/auth/Login'
import AddEmployee from './components/employee/add-employee/AddEmployee';
import ListEmployee from './components/employee/view-employee/ListEmployee';

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Fragment>
          
          <Switch>
                    <Route exact path="/" component={Login} />
                    <Route exact path="/add-employee" component={AddEmployee} />
                    <Route exact path="/list-employee" component={ListEmployee} />



          </Switch>
        </Fragment>
      </Router>
    </Provider>
  );
}

export default App;

import React from 'react'

const ListEmployee = () => {
    return (
        <div className="">

            <table className="table">
                <thead>
                    <tr>
                        <th> Name</th>
                        <th> Email</th>
                        <th> Address</th>
                        <th> Mobile</th>
                        <th> Salary</th>

                        <th> Action </th>
                    </tr>
                </thead>
                <tbody>
                        <tr >
                            <td >Sharath </td>
                            <td >Sharath </td>
                            <td > Sharath</td>
                            <td > Sharath</td>
                            <td > Sharath</td>

                            <td> 
                                <button className="btn btn-primary mr-2">Edit</button>
                                <button className="btn btn-danger">Delete</button>

                            </td>

                           </tr>
                
                    

                </tbody>
            </table>

        </div>
    );
}

export default ListEmployee;

import axios from 'axios';
import {
    ADD_EMPLOYEE,
} from './types';

// Register Employee
export const register = ({ empId, name, age, email, mobile, salary, address, password  }) => async dispatch => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
  
    const body = JSON.stringify({ empId, name, age, email, mobile, salary, address, password  });

    debugger;
  
    const res = await axios.post('/api/employee', body, config);
  
    dispatch({
      type: ADD_EMPLOYEE,
      payload: res.data
    });
  };
  
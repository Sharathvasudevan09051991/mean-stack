export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAIL = 'LOGIN_FAIL';

//Employee Registration
export const ADD_EMPLOYEE = 'ADD_EMPLOYEE';
export const VIEW_EMPLOYEE = 'VIEW_EMPLOYEE';

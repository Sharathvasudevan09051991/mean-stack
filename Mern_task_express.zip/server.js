const express = require('express');
const connectDB = require('./config/db')
var cors = require('cors')

const app = express();

app.use(cors());

connectDB();

app.use(express.json({extended: false}));

const PORT = process.env.PORT || 5000;

app.get('/', (req, res) => {
    res.send('API RUNNING');
})

app.use('/api/employee', require('./api/routes/Employees/employee'))
app.use('/api/employee-list', require('./api/routes/Employees/employee-list'))
app.use('/api/auth', require('./api/routes/auth/auth'))
app.use('/api/users', require('./api/routes/user/users'))



app.listen(PORT, () => console.log(`Connect port ${PORT}`));


const express = require("express");
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');
const { check, validationResult } = require('express-validator');
const Employee = require('../../../models/employee');


router.get("/",  async (req, res) => {
    try {
      const employee = await Employee.findById(req.employee.id).select("-password");
      res.json(employee);
    } catch (err) {
      res.status(500).send("Server Error");
    }
  });

//@route POST API
router.post('/',[
    check('email', "Valid Email Address").isEmail(),
    check('password', "Password required").exists()
],
 async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        return res.status(400).json({errors: errors.array()})
    }
        const {email, password} = req.body;

        try{
        let employee = await Employee.findOne({ email });

        if (!employee) {
            return res
              .status(400)
              .json({ errors: [{ msg: 'Invalid Credentials' }] });
          }

           const isMatch = await bcrypt.compare(password, employee.password);

        if(!isMatch){
            return res.status(400).json({ errors: [{msg : 'Invalid Credentials'}]});
        }  

        res.json({ employee })


        }catch(err){
        console.log(err.message);
        res.status(500).send('Server Error');
        }

})

module.exports = router;

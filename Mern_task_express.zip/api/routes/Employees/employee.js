const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const Employee = require('../../../models/employee');

router.post('/', async (req, res) => {

    const { empId, name, age, email, mobile, salary, address, password  } = req.body;

    let employee =  await Employee.findOne({empId});

    if(employee){
        return res.status(400).json({ errors: [{msg : 'Employee Already Exist'}]});
    }    

    employee = new Employee({
        empId, name, age, email, mobile, salary, address, password 
    })

    const salt = await bcrypt.genSalt(10);

    employee.password = await bcrypt.hash(password, salt);

    await employee.save();

    res.send("Employee Registered");


})

module.exports = router;
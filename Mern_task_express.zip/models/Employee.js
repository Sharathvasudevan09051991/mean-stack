const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
    
        empId: {
          type: String,
          required : true,
          unique: true
        },

        name: {
          type: String,
          required : true,
        },
        
        age: {
          type: String,
          required : true,
        },

        email: {
          type: String,
          required : true,
          unique: true
        },

        mobile: {
          type: String,
          required : true,
          unique: true
        },

        address: {
          type:String,      
      },

        salary:{
        type:String
        },

        password:{
          type :String,
          required : true
        }
      });
    


module.exports = Employee = mongoose.model('employee', EmployeeSchema)